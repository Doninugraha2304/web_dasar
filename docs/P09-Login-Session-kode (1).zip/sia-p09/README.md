# SIA Praktikum - Pertemuan 9 (Login Session)

Kode awal praktikum Pemrograman Web. Lanjutan dari CRUD Mahasiswa (Praktikum 5-7).

Fitur pada tahap ini:
- login dan logout dengan session
- password disimpan sebagai hash (password_hash)
- semua halaman data hanya terbuka setelah login

## Cara menjalankan

1. Ekstrak folder sia-p09 ke C:\xampp\htdocs.
2. Jalankan Apache dan MySQL di XAMPP Control Panel.
3. Buka phpMyAdmin, tab Import, pilih database.sql. File ini membuat database sia_praktikum dan aman diimpor ulang.
4. Sesuaikan port pada koneksi.php: paket laboratorium 3307, XAMPP standar 3306.
5. Buka http://localhost/sia-p09/public/daftar-akun.php, buat akun latihan, lalu masuk melalui login.php.

Jalankan melalui Apache/PHP (http://localhost/...), bukan dengan membuka file langsung.

## Isi folder

| File | Tugas |
| --- | --- |
| koneksi.php | Koneksi PDO ke database sia_praktikum |
| database.sql | Membuat database dan tabel; aman dijalankan ulang |
| public/login.php | Masuk (password_verify, session_regenerate_id) |
| public/daftar-akun.php | Membuat akun latihan (password_hash) |
| public/logout.php | Keluar melalui POST bertoken |
| public/wajib-login.php | Penjaga halaman: alihkan ke login bila belum masuk |
| public/nav.php | Navigasi dan tombol Keluar |
| public/form.php | Daftar dan tambah mahasiswa |
| public/tambah.php, edit.php, ubah.php, hapus.php | CRUD mahasiswa |

## Catatan keamanan

- Gunakan data fiktif. Jangan memakai password yang Anda pakai di akun lain.
- daftar-akun.php hanya untuk latihan lokal. Pada sistem nyata akun dibuat oleh admin.
- Paket ini untuk laptop sendiri (localhost), belum siap dipasang di server publik.
